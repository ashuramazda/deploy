<div class="row">
    <div class="col-md-8">
        {{ Form::text('name', trans('attribute::attributes.attribute_sets.name'), $errors, $attributeSet, ['required' => true]) }}
    </div>
</div>
