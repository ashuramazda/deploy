<?php

return [
    'service_unavailable' => 'Service Unavailable',
    'in_maintenance' => 'Sorry, we are doing some maintenance. Please check back soon.',
    'mail_is_not_configured' => 'Mail is not configured properly, please contact administrator.',
];
