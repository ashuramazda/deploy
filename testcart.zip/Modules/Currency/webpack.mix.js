let mix = require('laravel-mix');

mix.js('Modules/Currency/Resources/assets/admin/js/main.js', 'Modules/Currency/Assets/admin/js/currency.js');
